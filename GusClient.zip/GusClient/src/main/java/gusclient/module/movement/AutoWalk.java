package gusclient.module.movement;

import gusclient.module.*;
import gusclient.setting.*;

public class AutoWalk extends Module {
    private final ModeSetting direction = add(new ModeSetting("Direction", "Forward", "Forward", "Backward", "Left", "Right"));
    private final BoolSetting stopOnGui = add(new BoolSetting("Stop On GUI", true));
    private final BoolSetting stopOnCollision = add(new BoolSetting("Stop On Collision", false));

    public AutoWalk() { super("AutoWalk", Category.MOVEMENT); }

    @Override public void onTick() {
        var p = mc.player;
        if (p == null) return;
        boolean stop = (stopOnGui.get() && mc.screen != null) || (stopOnCollision.get() && p.horizontalCollision);
        release();
        if (stop) return;
        switch (direction.get()) {
            case "Backward" -> mc.options.keyDown.setDown(true);
            case "Left" -> mc.options.keyLeft.setDown(true);
            case "Right" -> mc.options.keyRight.setDown(true);
            default -> mc.options.keyUp.setDown(true);
        }
    }

    private void release() {
        mc.options.keyUp.setDown(false);
        mc.options.keyDown.setDown(false);
        mc.options.keyLeft.setDown(false);
        mc.options.keyRight.setDown(false);
    }

    @Override protected void onDisable() { release(); }
}
