package gusclient.module.render;

import gusclient.module.*;
import gusclient.setting.*;
import gusclient.util.Projector;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.level.block.ChestBlock;
import net.minecraft.world.level.block.entity.*;
import net.minecraft.world.level.block.state.properties.ChestType;
import net.minecraft.world.phys.AABB;
import java.util.ArrayList;
import java.util.List;

public class StorageESP extends Module implements Overlay {
    private final NumberSetting range = add(new NumberSetting("Range", 64, 8, 256, 8));
    private final NumberSetting thickness = add(new NumberSetting("Line Thickness", 1, 1, 4, 1));
    private final NumberSetting opacity = add(new NumberSetting("Opacity", 1.0, 0.2, 1.0, 0.1));
    private final BoolSetting names = add(new BoolSetting("Show Names", true));
    private final BoolSetting chest = add(new BoolSetting("Chest", true));
    private final BoolSetting trapped = add(new BoolSetting("Trapped Chest", true));
    private final BoolSetting barrel = add(new BoolSetting("Barrel", true));
    private final BoolSetting ender = add(new BoolSetting("Ender Chest", true));
    private final BoolSetting shulker = add(new BoolSetting("Shulker Box", true));

    private record Entry(AABB box, int color, String label) {}
    private volatile List<Entry> entries = List.of();
    private int tick;

    public StorageESP() { super("StorageESP", Category.STORAGE); }

    @Override public void onTick() {
        if (mc.player == null || mc.level == null) return;
        if (tick++ % 10 != 0) return;
        List<Entry> out = new ArrayList<>();
        int pcx = mc.player.getBlockX() >> 4, pcz = mc.player.getBlockZ() >> 4;
        int cr = (int) Math.ceil(range.get() / 16.0);
        double r2 = range.get() * range.get();
        for (int cx = pcx - cr; cx <= pcx + cr; cx++) {
            for (int cz = pcz - cr; cz <= pcz + cr; cz++) {
                var chunk = mc.level.getChunkSource().getChunkNow(cx, cz);
                if (chunk == null) continue;
                for (var e : chunk.getBlockEntities().values()) {
                    BlockPos pos = e.getBlockPos();
                    if (mc.player.distanceToSqr(pos.getX() + .5, pos.getY() + .5, pos.getZ() + .5) > r2) continue;
                    Entry en = classify(e, pos);
                    if (en != null) out.add(en);
                }
            }
        }
        entries = out;
    }

    private Entry classify(BlockEntity e, BlockPos pos) {
        AABB single = new AABB(pos);
        if (e instanceof TrappedChestBlockEntity) return trapped.get() ? chestEntry(e, pos, "Trapped Chest", 0xFF5555) : null;
        if (e instanceof ChestBlockEntity) return chest.get() ? chestEntry(e, pos, "Chest", 0xFFAA00) : null;
        if (e instanceof BarrelBlockEntity) return barrel.get() ? new Entry(single, 0xB07A3A, "Barrel") : null;
        if (e instanceof EnderChestBlockEntity) return ender.get() ? new Entry(single, 0xAA55FF, "Ender Chest") : null;
        if (e instanceof ShulkerBoxBlockEntity) return shulker.get() ? new Entry(single, 0xFF55FF, "Shulker Box") : null;
        return null;
    }

    private Entry chestEntry(BlockEntity e, BlockPos pos, String name, int color) {
        var state = e.getBlockState();
        if (!state.hasProperty(ChestBlock.TYPE)) return new Entry(new AABB(pos), color, name);
        ChestType t = state.getValue(ChestBlock.TYPE);
        if (t == ChestType.SINGLE) return new Entry(new AABB(pos), color, name);
        if (t == ChestType.RIGHT) return null; // sisi LEFT yang menggambar kotak gabungan
        Direction d = ChestBlock.getConnectedDirection(state);
        return new Entry(new AABB(pos).minmax(new AABB(pos.relative(d))), color, "Double " + name);
    }

    @Override public void renderOverlay(GuiGraphics g) {
        int t = thickness.i();
        for (Entry e : entries) {
            int col = Projector.withAlpha(e.color(), opacity.get());
            int[] top = Projector.drawBox(g, e.box(), col, t);
            if (top != null && names.get())
                g.drawCenteredString(mc.font, e.label(), top[0], top[1] - 10, col);
        }
    }

    @Override protected void onDisable() { entries = List.of(); tick = 0; }
}
