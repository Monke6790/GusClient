package gusclient.module.movement;

import gusclient.module.*;
import gusclient.setting.*;
import gusclient.util.MoveUtil;

public class FastFall extends Module {
    private final NumberSetting speed = add(new NumberSetting("Fall Speed", 1.0, 0.1, 3.0, 0.1));
    public FastFall() { super("FastFall", Category.MOVEMENT); }

    @Override public void onTick() {
        var p = mc.player;
        if (p == null || p.onGround() || p.isFallFlying() || p.isInWater() || p.getAbilities().flying) return;
        if (p.getDeltaMovement().y < 0) MoveUtil.setY(p, -speed.get());
    }
}
