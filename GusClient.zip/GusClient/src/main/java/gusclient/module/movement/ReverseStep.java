package gusclient.module.movement;

import gusclient.module.*;
import gusclient.setting.*;
import gusclient.util.MoveUtil;

public class ReverseStep extends Module {
    private final NumberSetting height = add(new NumberSetting("Height", 2.0, 0.5, 3.0, 0.1));
    private final NumberSetting speed = add(new NumberSetting("Speed", 1.0, 0.2, 3.0, 0.1));
    public ReverseStep() { super("ReverseStep", Category.MOVEMENT); }

    @Override public void onTick() {
        var p = mc.player;
        if (p == null || p.onGround() || p.isInWater() || p.isFallFlying() || p.getDeltaMovement().y > 0) return;
        var box = p.getBoundingBox().move(0, -height.get(), 0);
        if (!mc.level.noCollision(p, box)) MoveUtil.setY(p, -speed.get());
    }
}
