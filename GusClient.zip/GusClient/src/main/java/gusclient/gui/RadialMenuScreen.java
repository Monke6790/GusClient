package gusclient.gui;

import gusclient.GusClient;
import gusclient.module.*;
import gusclient.setting.Setting;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import java.util.*;

/** Radial menu: roda kategori + daftar module di kanan. */
public class RadialMenuScreen extends Screen {
    private static final int R_IN = 48, R_OUT = 125;
    private static final int BG = 0xE0140F1C, HOVER = 0xE0301A45, SEL = 0xFF7B2FBF, ROW = 0xE0120D18;
    private static final Category[] CATS = Category.values();
    private static Category selected = Category.BASEFINDING;
    private Module expanded;

    private record Hit(int x, int y, int w, int h, Runnable left, Runnable right) {
        boolean in(double mx, double my) { return mx >= x && mx < x + w && my >= y && my < y + h; }
    }
    private final List<Hit> hits = new ArrayList<>();

    public RadialMenuScreen() { super(Component.literal("GusClient")); }

    @Override public boolean isPauseScreen() { return false; }

    private int sectorAt(double mx, double my, int cx, int cy) {
        double dx = mx - cx, dy = my - cy, d = Math.hypot(dx, dy);
        if (d < R_IN || d > R_OUT) return -1;
        double a = (Math.atan2(dy, dx) + Math.PI / 2 + 2 * Math.PI) % (2 * Math.PI);
        return (int) (a / (2 * Math.PI / CATS.length));
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float delta) {
        int cx = width / 2, cy = height / 2;
        g.fill(0, 0, width, height, 0x90000000);
        int hover = sectorAt(mx, my, cx, cy);

        for (int y = -R_OUT; y <= R_OUT; y++) {
            int wo = (int) Math.sqrt((double) R_OUT * R_OUT - (double) y * y);
            int wi = Math.abs(y) < R_IN ? (int) Math.sqrt((double) R_IN * R_IN - (double) y * y) : -1;
            if (wi < 0) ring(g, cx, cy, y, -wo, wo, hover);
            else { ring(g, cx, cy, y, -wo, -wi, hover); ring(g, cx, cy, y, wi, wo, hover); }
        }
        g.fill(cx - 4, cy - 4, cx + 4, cy + 4, SEL);

        double step = 2 * Math.PI / CATS.length;
        for (int i = 0; i < CATS.length; i++) {
            double ang = -Math.PI / 2 + (i + 0.5) * step;
            int lx = cx + (int) (Math.cos(ang) * (R_IN + R_OUT) / 2), ly = cy + (int) (Math.sin(ang) * (R_IN + R_OUT) / 2);
            g.drawCenteredString(font, CATS[i].label, lx, ly - 4, 0xFFDDDDDD);
        }

        hits.clear();
        int x = cx + R_OUT + 24, y = cy - 100, w = 140;
        g.fill(x, y, x + w, y + 18, ROW);
        g.drawString(font, selected.label, x + 6, y + 5, 0xFFE9B8FF);
        y += 22;
        for (Module m : GusClient.modules.in(selected)) {
            final Module mod = m;
            hits.add(new Hit(x, y, w, 18, mod::toggle, () -> expanded = expanded == mod ? null : mod));
            g.fill(x, y, x + w, y + 18, ROW);
            g.drawString(font, m.name, x + 6, y + 5, 0xFFDDDDDD);
            g.fill(x + w - 30, y + 4, x + w - 6, y + 14, m.isEnabled() ? SEL : 0xFF3A3A44);
            y += 20;
            if (expanded == m) {
                for (Setting<?> s : m.settings) {
                    hits.add(new Hit(x + 8, y, w - 8, 16, s::onLeft, s::onRight));
                    g.fill(x + 8, y, x + w, y + 16, 0xE0201530);
                    g.drawString(font, s.name, x + 12, y + 4, 0xFFBBBBBB);
                    String v = s.display();
                    g.drawString(font, v, x + w - 6 - font.width(v), y + 4, 0xFFE9B8FF);
                    y += 18;
                }
            }
        }
        if (GusClient.modules.in(selected).isEmpty())
            g.drawString(font, "(belum ada module)", x + 6, y + 4, 0xFF777777);
    }

    private void ring(GuiGraphics g, int cx, int cy, int dy, int x0, int x1, int hover) {
        int runStart = x0, runCol = colorAt(x0, dy, hover);
        for (int x = x0 + 1; x <= x1; x++) {
            int c = colorAt(x, dy, hover);
            if (c != runCol) { g.fill(cx + runStart, cy + dy, cx + x, cy + dy + 1, runCol); runStart = x; runCol = c; }
        }
        g.fill(cx + runStart, cy + dy, cx + x1 + 1, cy + dy + 1, runCol);
    }

    private int colorAt(int dx, int dy, int hover) {
        double a = (Math.atan2(dy, dx) + Math.PI / 2 + 2 * Math.PI) % (2 * Math.PI);
        int i = (int) (a / (2 * Math.PI / CATS.length));
        if (CATS[i] == selected) return SEL;
        return i == hover ? HOVER : BG;
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent e, boolean dbl) {
        int cx = width / 2, cy = height / 2;
        int s = sectorAt(e.x(), e.y(), cx, cy);
        if (s >= 0) { selected = CATS[s]; expanded = null; return true; }
        for (Hit h : new ArrayList<>(hits)) if (h.in(e.x(), e.y())) {
            if (e.button() == 0) h.left().run(); else if (e.button() == 1) h.right().run();
            return true;
        }
        return super.mouseClicked(e, dbl);
    }

    @Override public void onClose() { GusClient.config.save(); super.onClose(); }
}
