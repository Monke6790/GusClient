package gusclient.module.render;

import gusclient.module.*;
import gusclient.setting.*;

/** Zoom lewat FOV option; FOV asli dipulihkan saat dimatikan. */
public class Zoom extends Module {
    private final NumberSetting level = add(new NumberSetting("Zoom Level", 3.0, 1.5, 10.0, 0.5));
    private int originalFov = -1;

    public Zoom() { super("Zoom", Category.RENDER); }

    @Override protected void onEnable() {
        originalFov = mc.options.fov().get();
        apply();
    }

    @Override public void onTick() { apply(); }

    private void apply() {
        if (originalFov < 0) return;
        int target = (int) Math.max(30, Math.round(originalFov / level.get()));
        if (mc.options.fov().get() != target) mc.options.fov().set(target);
    }

    @Override protected void onDisable() {
        if (originalFov >= 0) mc.options.fov().set(originalFov);
        originalFov = -1;
    }
}
