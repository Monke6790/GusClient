package gusclient.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;
import java.util.List;

public class ModeSetting extends Setting<String> {
    public final List<String> modes;
    public ModeSetting(String n, String d, String... modes) { super(n, d); this.modes = List.of(modes); }
    public boolean is(String m) { return value.equalsIgnoreCase(m); }
    public JsonElement toJson() { return new JsonPrimitive(value); }
    public void fromJson(JsonElement e) { String s = e.getAsString(); if (modes.contains(s)) value = s; }
    public String display() { return value; }
    public void onLeft() { value = modes.get((modes.indexOf(value) + 1) % modes.size()); }
    @Override public void onRight() { value = modes.get((modes.indexOf(value) - 1 + modes.size()) % modes.size()); }
}
