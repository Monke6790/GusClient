package gusclient.module.render;

import gusclient.module.*;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;

/** Night vision lokal (client-side). Efek asli dari server tidak dihapus saat dimatikan. */
public class Fullbright extends Module {
    private boolean hadRealEffect;

    public Fullbright() { super("Fullbright", Category.RENDER); }

    @Override protected void onEnable() {
        if (mc.player != null) hadRealEffect = mc.player.hasEffect(MobEffects.NIGHT_VISION);
    }

    @Override public void onTick() {
        var p = mc.player;
        if (p == null) return;
        var cur = p.getEffect(MobEffects.NIGHT_VISION);
        if (cur == null || cur.getDuration() < 400)
            p.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, 100000, 0, false, false, false));
    }

    @Override protected void onDisable() {
        if (mc.player != null && !hadRealEffect) mc.player.removeEffectNoUpdate(MobEffects.NIGHT_VISION);
    }
}
