package gusclient.module;

import gusclient.setting.Setting;
import net.minecraft.client.Minecraft;
import java.util.ArrayList;
import java.util.List;

public abstract class Module {
    public final String name;
    public final Category category;
    public final List<Setting<?>> settings = new ArrayList<>();
    protected final Minecraft mc = Minecraft.getInstance();
    private boolean enabled;
    public int key = -1; // GLFW key, -1 = none

    protected Module(String name, Category category) { this.name = name; this.category = category; }

    protected <S extends Setting<?>> S add(S s) { settings.add(s); return s; }
    public boolean isEnabled() { return enabled; }

    public void setEnabled(boolean on) {
        if (on == enabled) return;
        enabled = on;
        try { if (on) onEnable(); else onDisable(); }
        catch (Throwable t) { System.err.println("[GusClient] " + name + " error: " + t); enabled = false; }
    }
    public void toggle() { setEnabled(!enabled); }

    protected void onEnable() {}
    /** Wajib memulihkan semua state yang diubah module. */
    protected void onDisable() {}
    public void onTick() {}
}
