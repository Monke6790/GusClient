package gusclient;

import gusclient.config.ConfigManager;
import gusclient.gui.RadialMenuScreen;
import gusclient.module.ModuleManager;
import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.Minecraft;
import org.lwjgl.glfw.GLFW;

public class GusClient implements ClientModInitializer {
    public static final String NAME = "GusClient";
    public static ModuleManager modules;
    public static ConfigManager config;
    private boolean menuKeyDown;

    @Override
    public void onInitializeClient() {
        modules = new ModuleManager();
        modules.init();
        config = new ConfigManager(modules);
        config.load();

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            try {
                if (mc.player == null || mc.level == null) return;
                boolean down = InputConstants.isKeyDown(mc.getWindow(), GLFW.GLFW_KEY_RIGHT_SHIFT);
                if (down && !menuKeyDown && mc.screen == null) mc.setScreen(new RadialMenuScreen());
                menuKeyDown = down;
                modules.tick(mc);
            } catch (Throwable t) {
                System.err.println("[GusClient] tick error: " + t);
            }
        });
        ClientLifecycleEvents.CLIENT_STOPPING.register(mc -> { modules.disableAll(); config.save(); });
    }

    public static Minecraft mc() { return Minecraft.getInstance(); }
}
