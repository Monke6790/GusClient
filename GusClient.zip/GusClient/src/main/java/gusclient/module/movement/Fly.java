package gusclient.module.movement;

import gusclient.module.*;
import gusclient.setting.*;
import gusclient.util.MoveUtil;

public class Fly extends Module {
    private final NumberSetting hSpeed = add(new NumberSetting("Horizontal Speed", 0.6, 0.1, 3.0, 0.1));
    private final NumberSetting vSpeed = add(new NumberSetting("Vertical Speed", 0.4, 0.1, 2.0, 0.1));
    public Fly() { super("Fly", Category.MOVEMENT); }

    @Override public void onTick() {
        var p = mc.player;
        if (p == null || p.isFallFlying() || mc.screen != null) return;
        double y = mc.options.keyJump.isDown() ? vSpeed.get() : mc.options.keyShift.isDown() ? -vSpeed.get() : 0;
        MoveUtil.setY(p, y);
        if (MoveUtil.isMoving(p)) MoveUtil.setSpeed(p, hSpeed.get());
        else p.setDeltaMovement(0, y, 0);
        p.fallDistance = 0;
    }
}
