package gusclient.module.movement;

import gusclient.module.*;
import gusclient.setting.*;
import gusclient.util.MoveUtil;

public class Speed extends Module {
    private final NumberSetting ground = add(new NumberSetting("Ground Speed", 0.28, 0.1, 1.0, 0.01));
    private final NumberSetting air = add(new NumberSetting("Air Speed", 0.28, 0.1, 1.0, 0.01));
    public Speed() { super("Speed", Category.MOVEMENT); }

    @Override public void onTick() {
        var p = mc.player;
        if (p == null || p.isFallFlying() || p.isInWater() || !MoveUtil.isMoving(p)) return;
        MoveUtil.setSpeed(p, p.onGround() ? ground.get() : air.get());
    }
}
