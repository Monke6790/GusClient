package gusclient.module;

import com.mojang.blaze3d.platform.InputConstants;
import gusclient.module.movement.*;
import gusclient.module.render.*;
import net.minecraft.client.Minecraft;
import java.util.*;

public class ModuleManager {
    private final Map<String, Module> byName = new LinkedHashMap<>();
    private final Set<Integer> held = new HashSet<>();

    public void init() {
        register(new Sprint());
        register(new AutoWalk());
        register(new Step());
        register(new Fullbright());
        register(new Zoom());
        // Fase berikutnya: module lain didaftarkan di sini.
    }

    public void register(Module m) {
        if (byName.putIfAbsent(m.name.toLowerCase(), m) != null)
            throw new IllegalStateException("Duplicate module: " + m.name);
    }

    public Collection<Module> all() { return byName.values(); }
    public Module get(String n) { return byName.get(n.toLowerCase()); }
    public List<Module> in(Category c) { return byName.values().stream().filter(m -> m.category == c).toList(); }

    public void tick(Minecraft mc) {
        for (Module m : byName.values()) {
            if (m.key >= 0 && mc.screen == null) {
                boolean down = InputConstants.isKeyDown(mc.getWindow(), m.key);
                if (down && held.add(m.key)) m.toggle();
                else if (!down) held.remove(m.key);
            }
            if (m.isEnabled()) {
                try { m.onTick(); }
                catch (Throwable t) { System.err.println("[GusClient] " + m.name + ": " + t); m.setEnabled(false); }
            }
        }
    }

    public void disableAll() { byName.values().forEach(m -> m.setEnabled(false)); }
}
