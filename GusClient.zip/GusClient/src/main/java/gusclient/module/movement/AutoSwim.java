package gusclient.module.movement;

import gusclient.module.*;
import gusclient.setting.*;
import gusclient.util.MoveUtil;

public class AutoSwim extends Module {
    private final NumberSetting speed = add(new NumberSetting("Swim Speed", 0.3, 0.1, 1.0, 0.05));
    private final BoolSetting vertical = add(new BoolSetting("Vertical Control", true));
    public AutoSwim() { super("AutoSwim", Category.MOVEMENT); }

    @Override public void onTick() {
        var p = mc.player;
        if (p == null || !p.isInWater() || !MoveUtil.isMoving(p)) return;
        MoveUtil.setSpeed(p, speed.get());
        if (vertical.get()) MoveUtil.setY(p, -Math.sin(Math.toRadians(p.getXRot())) * speed.get());
    }
}
