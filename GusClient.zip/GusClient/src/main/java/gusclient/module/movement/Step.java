package gusclient.module.movement;

import gusclient.module.*;
import gusclient.setting.*;
import net.minecraft.world.entity.ai.attributes.Attributes;

public class Step extends Module {
    private final NumberSetting height = add(new NumberSetting("Step Height", 1.0, 0.6, 2.5, 0.1));
    private static final double DEFAULT = 0.6;

    public Step() { super("Step", Category.MOVEMENT); }

    @Override public void onTick() {
        if (mc.player == null) return;
        var attr = mc.player.getAttribute(Attributes.STEP_HEIGHT);
        if (attr != null && attr.getBaseValue() != height.get()) attr.setBaseValue(height.get());
    }

    @Override protected void onDisable() {
        if (mc.player == null) return;
        var attr = mc.player.getAttribute(Attributes.STEP_HEIGHT);
        if (attr != null) attr.setBaseValue(DEFAULT);
    }
}
