package gusclient.module.movement;

import gusclient.module.*;
import gusclient.setting.*;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket;

public class NoFall extends Module {
    private final NumberSetting distance = add(new NumberSetting("Min Distance", 2.5, 1.0, 10.0, 0.5));
    private final BoolSetting debug = add(new BoolSetting("Debug Mode", false));
    public NoFall() { super("NoFall", Category.MOVEMENT); }

    @Override public void onTick() {
        var p = mc.player;
        if (p == null || p.isFallFlying() || p.getAbilities().flying || p.connection == null) return;
        if (p.fallDistance > distance.get() && !p.onGround()) {
            p.connection.send(new ServerboundMovePlayerPacket.StatusOnly(true, p.horizontalCollision));
            if (debug.get()) p.displayClientMessage(Component.literal("NoFall: fall=" + String.format("%.1f", p.fallDistance)), true);
        }
    }
}
