package gusclient.util;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/**
 * Proyeksi 3D -> layar 2D buatan sendiri (tanpa pipeline render dunia),
 * supaya ESP tidak bergantung pada API render 3D yang berubah-ubah.
 * Kamera diasumsikan = mata player (belum mendukung Freecam/Freelook).
 */
public final class Projector {
    private static double ex, ey, ez, fx, fy, fz, rx, rz, ux, uy, uz, scale, W, H;

    private Projector() {}

    public static void begin(Minecraft mc, float pt) {
        var p = mc.player;
        Vec3 eye = p.getEyePosition(pt);
        ex = eye.x; ey = eye.y; ez = eye.z;
        double yaw = Math.toRadians(p.getViewYRot(pt)), pitch = Math.toRadians(p.getViewXRot(pt));
        fx = -Math.sin(yaw) * Math.cos(pitch); fy = -Math.sin(pitch); fz = Math.cos(yaw) * Math.cos(pitch);
        rx = -Math.cos(yaw); rz = -Math.sin(yaw);
        ux = 0 * fz - rz * fy;
        uy = rz * fx - rx * fz;
        uz = rx * fy - 0 * fx;
        W = mc.getWindow().getGuiScaledWidth();
        H = mc.getWindow().getGuiScaledHeight();
        scale = (H / 2) / Math.tan(Math.toRadians(mc.options.fov().get()) / 2);
    }

    /** @return {sx, sy} atau null kalau di belakang kamera */
    public static double[] project(double x, double y, double z) {
        double dx = x - ex, dy = y - ey, dz = z - ez;
        double depth = dx * fx + dy * fy + dz * fz;
        if (depth < 0.05) return null;
        double sx = dx * rx + dz * rz;
        double sy = dx * ux + dy * uy + dz * uz;
        return new double[]{W / 2 + sx / depth * scale, H / 2 - sy / depth * scale};
    }

    public static int withAlpha(int rgb, double alpha) {
        return ((int) (Math.max(0, Math.min(1, alpha)) * 255) << 24) | (rgb & 0xFFFFFF);
    }

    public static void line(GuiGraphics g, int x1, int y1, int x2, int y2, int color, int t) {
        g.fill(Math.min(x1, x2), Math.min(y1, y2), Math.max(x1, x2) + t, Math.max(y1, y2) + t, color);
    }

    /** Gambar kotak 2D di sekeliling box 3D. @return titik atas-tengah {x,y} atau null. */
    public static int[] drawBox(GuiGraphics g, AABB b, int color, int thickness) {
        double minX = 1e9, minY = 1e9, maxX = -1e9, maxY = -1e9;
        for (int i = 0; i < 8; i++) {
            double[] s = project((i & 1) == 0 ? b.minX : b.maxX, (i & 2) == 0 ? b.minY : b.maxY, (i & 4) == 0 ? b.minZ : b.maxZ);
            if (s == null) return null;
            minX = Math.min(minX, s[0]); maxX = Math.max(maxX, s[0]);
            minY = Math.min(minY, s[1]); maxY = Math.max(maxY, s[1]);
        }
        if (maxX - minX > 3000 || maxY - minY > 3000 || maxX < 0 || minX > W || maxY < 0 || minY > H) return null;
        int x1 = (int) minX, y1 = (int) minY, x2 = (int) maxX, y2 = (int) maxY;
        line(g, x1, y1, x2, y1, color, thickness);
        line(g, x1, y2, x2, y2, color, thickness);
        line(g, x1, y1, x1, y2, color, thickness);
        line(g, x2, y1, x2, y2, color, thickness);
        return new int[]{(x1 + x2) / 2, y1};
    }
}
