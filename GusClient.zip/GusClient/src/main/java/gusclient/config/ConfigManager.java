package gusclient.config;

import com.google.gson.*;
import gusclient.module.*;
import gusclient.setting.Setting;
import net.fabricmc.loader.api.FabricLoader;
import java.nio.file.*;

public class ConfigManager {
    private final ModuleManager mm;
    private final Path file = FabricLoader.getInstance().getConfigDir().resolve("gusclient.json");
    private final Gson gson = new GsonBuilder().setPrettyPrinting().create();

    public ConfigManager(ModuleManager mm) { this.mm = mm; }

    public void save() {
        try {
            JsonObject root = new JsonObject();
            for (Module m : mm.all()) {
                JsonObject o = new JsonObject();
                o.addProperty("enabled", m.isEnabled());
                o.addProperty("key", m.key);
                JsonObject s = new JsonObject();
                for (Setting<?> st : m.settings) s.add(st.name, st.toJson());
                o.add("settings", s);
                root.add(m.name, o);
            }
            Files.writeString(file, gson.toJson(root));
        } catch (Exception e) { System.err.println("[GusClient] save failed: " + e); }
    }

    public void load() {
        if (!Files.exists(file)) return;
        try {
            JsonObject root = JsonParser.parseString(Files.readString(file)).getAsJsonObject();
            for (Module m : mm.all()) {
                if (!root.has(m.name)) continue;
                JsonObject o = root.getAsJsonObject(m.name);
                if (o.has("key")) m.key = o.get("key").getAsInt();
                if (o.has("settings")) {
                    JsonObject s = o.getAsJsonObject("settings");
                    for (Setting<?> st : m.settings) if (s.has(st.name)) {
                        try { st.fromJson(s.get(st.name)); } catch (Exception ignored) {}
                    }
                }
                if (o.has("enabled")) m.setEnabled(o.get("enabled").getAsBoolean());
            }
        } catch (Exception e) { System.err.println("[GusClient] load failed (config diabaikan): " + e); }
    }
}
