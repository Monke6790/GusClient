package gusclient.module;

import net.minecraft.client.gui.GuiGraphics;

/** Module yang menggambar overlay 2D di atas dunia (lewat HUD callback). */
public interface Overlay {
    void renderOverlay(GuiGraphics g);
}
