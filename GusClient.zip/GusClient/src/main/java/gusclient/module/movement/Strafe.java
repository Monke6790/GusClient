package gusclient.module.movement;

import gusclient.module.*;
import gusclient.setting.*;
import gusclient.util.MoveUtil;

public class Strafe extends Module {
    private final NumberSetting speed = add(new NumberSetting("Speed", 0.28, 0.1, 1.0, 0.01));
    private final BoolSetting airControl = add(new BoolSetting("Air Control", true));
    private final BoolSetting groundControl = add(new BoolSetting("Ground Control", false));
    public Strafe() { super("Strafe", Category.MOVEMENT); }

    @Override public void onTick() {
        var p = mc.player;
        if (p == null || p.isFallFlying() || p.isInWater() || !MoveUtil.isMoving(p)) return;
        boolean ok = p.onGround() ? groundControl.get() : airControl.get();
        if (ok) MoveUtil.setSpeed(p, Math.max(speed.get(), MoveUtil.hSpeed(p)));
    }
}
