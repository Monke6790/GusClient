package gusclient.module.render;

import gusclient.module.*;
import gusclient.setting.*;
import gusclient.util.Projector;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.phys.AABB;
import java.nio.file.Files;
import java.util.*;

/**
 * Menghitung Amethyst Cluster matang per chunk (hanya chunk yang sudah dimuat).
 * Hasil BUKAN bukti pasti chunk pernah dipakai pemain; hanya label "High Mature Cluster Count".
 */
public class SusChunkFinder extends Module implements Overlay {
    private final NumberSetting scanRange = add(new NumberSetting("Scan Range (chunks)", 8, 2, 16, 1));
    private final NumberSetting threshold = add(new NumberSetting("Min Clusters", 10, 1, 200, 1));
    private final BoolSetting overlay = add(new BoolSetting("Overlay", true));
    private final BoolSetting boxes = add(new BoolSetting("Cluster Boxes", true));
    private final BoolSetting clear = add(new BoolSetting("Clear Results", false));
    private final BoolSetting save = add(new BoolSetting("Save Results", false));

    private static final class Result {
        int mature, small, medium, large; double sumY;
        final List<BlockPos> clusters = new ArrayList<>();
        int cx, cz;
    }

    private final Map<Long, Result> results = new HashMap<>();
    private final ArrayDeque<long[]> queue = new ArrayDeque<>();
    private Object lastLevel;
    private int ticks;

    public SusChunkFinder() { super("SusChunkFinder", Category.BASEFINDING); }

    private static long key(int x, int z) { return ((long) x << 32) | (z & 0xFFFFFFFFL); }

    @Override public void onTick() {
        if (mc.player == null || mc.level == null) return;
        if (lastLevel != mc.level) { results.clear(); queue.clear(); lastLevel = mc.level; }
        if (clear.get()) { results.clear(); clear.set(false); }
        if (save.get()) { saveResults(); save.set(false); }

        // isi antrian tiap 10 detik, scan maksimal 1 chunk per tick agar tidak membebani main thread
        if (queue.isEmpty() && ticks++ % 200 == 0) {
            int pcx = mc.player.getBlockX() >> 4, pcz = mc.player.getBlockZ() >> 4, r = scanRange.i();
            for (int x = pcx - r; x <= pcx + r; x++)
                for (int z = pcz - r; z <= pcz + r; z++) queue.add(new long[]{x, z});
        }
        long[] next = queue.poll();
        if (next == null) return;
        LevelChunk c = mc.level.getChunkSource().getChunkNow((int) next[0], (int) next[1]);
        if (c != null) results.put(key((int) next[0], (int) next[1]), scan(c, (int) next[0], (int) next[1]));
    }

    private Result scan(LevelChunk c, int cx, int cz) {
        Result r = new Result(); r.cx = cx; r.cz = cz;
        var sections = c.getSections();
        int minY = mc.level.getMinY();
        for (int i = 0; i < sections.length; i++) {
            var sec = sections[i];
            if (sec == null || sec.hasOnlyAir()) continue;
            if (!sec.maybeHas(SusChunkFinder::isAmethyst)) continue;
            int baseY = minY + i * 16;
            for (int x = 0; x < 16; x++) for (int y = 0; y < 16; y++) for (int z = 0; z < 16; z++) {
                BlockState s = sec.getBlockState(x, y, z);
                if (!isAmethyst(s)) continue;
                if (s.is(Blocks.AMETHYST_CLUSTER)) {
                    r.mature++; r.sumY += baseY + y;
                    r.clusters.add(new BlockPos(cx * 16 + x, baseY + y, cz * 16 + z));
                } else if (s.is(Blocks.LARGE_AMETHYST_BUD)) r.large++;
                else if (s.is(Blocks.MEDIUM_AMETHYST_BUD)) r.medium++;
                else r.small++;
            }
        }
        return r;
    }

    private static boolean isAmethyst(BlockState s) {
        return s.is(Blocks.AMETHYST_CLUSTER) || s.is(Blocks.LARGE_AMETHYST_BUD)
                || s.is(Blocks.MEDIUM_AMETHYST_BUD) || s.is(Blocks.SMALL_AMETHYST_BUD);
    }

    private List<Result> flagged() {
        List<Result> out = new ArrayList<>();
        for (Result r : results.values()) if (r.mature >= threshold.i()) out.add(r);
        out.sort((a, b) -> Integer.compare(b.mature, a.mature));
        return out;
    }

    @Override public void renderOverlay(GuiGraphics g) {
        if (!overlay.get()) return;
        List<Result> list = flagged();
        int y = 40;
        g.drawString(mc.font, "SusChunks: " + list.size() + " flagged / " + results.size() + " scanned", 4, y, 0xFFE9B8FF);
        for (int i = 0; i < Math.min(8, list.size()); i++) {
            Result r = list.get(i);
            y += 10;
            g.drawString(mc.font, "Chunk [" + r.cx + "," + r.cz + "] block " + r.cx * 16 + "," + r.cz * 16
                    + " clusters=" + r.mature, 4, y, 0xFFDDDDDD);
        }
        int drawn = 0;
        for (Result r : list) {
            double cy = r.sumY / Math.max(1, r.mature);
            double[] s = Projector.project(r.cx * 16 + 8, cy, r.cz * 16 + 8);
            if (s != null) g.drawCenteredString(mc.font, "Interesting Chunk (" + r.mature + ")", (int) s[0], (int) s[1], 0xFFFF77FF);
            if (boxes.get()) for (BlockPos p : r.clusters) {
                if (drawn >= 150) break;
                if (mc.player.distanceToSqr(p.getX(), p.getY(), p.getZ()) > 96 * 96) continue;
                Projector.drawBox(g, new AABB(p), 0xFFAA66FF, 1);
                drawn++;
            }
        }
    }

    private void saveResults() {
        try {
            StringBuilder sb = new StringBuilder("# GusClient SusChunkFinder - High Mature Cluster Count (bukan bukti pasti)\n");
            for (Result r : flagged())
                sb.append(String.format("chunk %d %d | block %d %d | mature=%d large=%d medium=%d small=%d%n",
                        r.cx, r.cz, r.cx * 16, r.cz * 16, r.mature, r.large, r.medium, r.small));
            Files.writeString(FabricLoader.getInstance().getConfigDir().resolve("gusclient_suschunks.txt"), sb.toString());
        } catch (Exception e) { System.err.println("[GusClient] save sus chunks failed: " + e); }
    }

    @Override protected void onDisable() { queue.clear(); }
}
