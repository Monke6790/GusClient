package gusclient.module.movement;

import gusclient.module.*;
import gusclient.setting.*;
import net.minecraft.world.phys.Vec3;

public class ElytraFly extends Module {
    private final NumberSetting hSpeed = add(new NumberSetting("Horizontal Speed", 1.5, 0.5, 4.0, 0.1));
    private final NumberSetting vSpeed = add(new NumberSetting("Vertical Speed", 0.5, 0.1, 2.0, 0.1));
    public ElytraFly() { super("ElytraFly", Category.MOVEMENT); }

    @Override public void onTick() {
        var p = mc.player;
        if (p == null || !p.isFallFlying() || mc.screen != null) return;
        double y = mc.options.keyJump.isDown() ? vSpeed.get() : mc.options.keyShift.isDown() ? -vSpeed.get() : 0;
        Vec3 look = p.getLookAngle();
        double len = Math.hypot(look.x, look.z);
        if (p.zza > 0 && len > 1e-4) p.setDeltaMovement(look.x / len * hSpeed.get(), y, look.z / len * hSpeed.get());
        else p.setDeltaMovement(0, y, 0);
    }
}
