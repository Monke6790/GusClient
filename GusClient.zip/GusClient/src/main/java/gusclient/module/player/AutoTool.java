package gusclient.module.player;

import gusclient.module.*;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;

public class AutoTool extends Module {
    private int previous = -1;
    public AutoTool() { super("AutoTool", Category.MISC); }

    @Override public void onTick() {
        var p = mc.player;
        if (p == null || mc.level == null) return;
        boolean mining = mc.options.keyAttack.isDown() && mc.screen == null
                && mc.hitResult instanceof BlockHitResult bhr && mc.hitResult.getType() == HitResult.Type.BLOCK;
        if (!mining) { restore(); return; }
        var state = mc.level.getBlockState(((BlockHitResult) mc.hitResult).getBlockPos());
        int best = p.getInventory().getSelectedSlot();
        float bestSpeed = p.getInventory().getItem(best).getDestroySpeed(state);
        for (int i = 0; i < 9; i++) {
            float s = p.getInventory().getItem(i).getDestroySpeed(state);
            if (s > bestSpeed) { bestSpeed = s; best = i; }
        }
        if (best != p.getInventory().getSelectedSlot()) {
            if (previous < 0) previous = p.getInventory().getSelectedSlot();
            p.getInventory().setSelectedSlot(best);
        }
    }

    private void restore() {
        if (previous >= 0 && mc.player != null) mc.player.getInventory().setSelectedSlot(previous);
        previous = -1;
    }

    @Override protected void onDisable() { restore(); }
}
