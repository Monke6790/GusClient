package gusclient.setting;

import com.google.gson.JsonElement;

public abstract class Setting<T> {
    public final String name;
    protected T value;
    private final T def;
    protected Setting(String name, T def) { this.name = name; this.value = def; this.def = def; }
    public T get() { return value; }
    public void set(T v) { this.value = v; }
    public void reset() { this.value = def; }
    public abstract JsonElement toJson();
    public abstract void fromJson(JsonElement e);
    public abstract String display();
    public abstract void onLeft();
    public void onRight() { onLeft(); }
}
