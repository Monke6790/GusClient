package gusclient.module;

public enum Category {
    CLIENT("CLIENT"), COMBAT("COMBAT"), MOVEMENT("MOVEMENT"), BASEFINDING("BASE FINDING"),
    STORAGE("STORAGE"), RENDER("RENDER"), MISC("MISC");
    public final String label;
    Category(String l) { label = l; }
}
