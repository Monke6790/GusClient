package gusclient.module.movement;

import com.mojang.blaze3d.platform.InputConstants;
import gusclient.module.*;
import gusclient.setting.*;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.gui.screens.ChatScreen;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;

public class InvMove extends Module {
    private final BoolSetting inventory = add(new BoolSetting("Inventory", true));
    private final BoolSetting chat = add(new BoolSetting("Chat", false));
    private final BoolSetting sneak = add(new BoolSetting("Sneak", false));
    public InvMove() { super("InvMove", Category.MOVEMENT); }

    private boolean allowed() {
        var s = mc.screen;
        if (s == null || s instanceof ChatScreen) return s != null && chat.get();
        return inventory.get() && s instanceof AbstractContainerScreen;
    }

    private void sync(KeyMapping k) {
        int code = KeyBindingHelper.getBoundKeyOf(k).getValue();
        k.setDown(InputConstants.isKeyDown(mc.getWindow(), code));
    }

    @Override public void onTick() {
        if (mc.player == null || !allowed()) return;
        sync(mc.options.keyUp); sync(mc.options.keyDown); sync(mc.options.keyLeft);
        sync(mc.options.keyRight); sync(mc.options.keyJump);
        if (sneak.get()) sync(mc.options.keyShift);
    }
}
