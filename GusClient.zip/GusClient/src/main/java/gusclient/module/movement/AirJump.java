package gusclient.module.movement;

import gusclient.module.*;
import gusclient.setting.*;
import gusclient.util.MoveUtil;

public class AirJump extends Module {
    private final NumberSetting max = add(new NumberSetting("Maximum Air Jumps", 1, 1, 10, 1));
    private final NumberSetting delay = add(new NumberSetting("Jump Delay", 5, 0, 20, 1));
    private final BoolSetting reset = add(new BoolSetting("Reset On Ground", true));
    private int used, cooldown;
    private boolean wasDown;
    public AirJump() { super("AirJump", Category.MOVEMENT); }

    @Override public void onTick() {
        var p = mc.player;
        if (p == null || mc.screen != null) return;
        if (p.onGround() && reset.get()) used = 0;
        if (cooldown > 0) cooldown--;
        boolean down = mc.options.keyJump.isDown();
        if (down && !wasDown && !p.onGround() && !p.isInWater() && used < max.i() && cooldown == 0) {
            MoveUtil.setY(p, 0.42); used++; cooldown = delay.i();
        }
        wasDown = down;
    }

    @Override protected void onDisable() { used = 0; cooldown = 0; wasDown = false; }
}
