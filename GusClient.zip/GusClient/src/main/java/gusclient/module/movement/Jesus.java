package gusclient.module.movement;

import gusclient.module.*;
import gusclient.setting.*;
import gusclient.util.MoveUtil;

public class Jesus extends Module {
    private final NumberSetting speed = add(new NumberSetting("Speed", 0.1, 0.02, 0.4, 0.01));
    public Jesus() { super("Jesus", Category.MOVEMENT); }

    @Override public void onTick() {
        var p = mc.player;
        if (p == null || mc.options.keyShift.isDown()) return;
        if (p.isInWater() || p.isInLava()) MoveUtil.setY(p, speed.get());
    }
}
