package gusclient.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;

public class NumberSetting extends Setting<Double> {
    public final double min, max, step;
    public NumberSetting(String n, double d, double min, double max, double step) { super(n, d); this.min = min; this.max = max; this.step = step; }
    @Override public void set(Double v) { value = Math.max(min, Math.min(max, v)); }
    public float f() { return value.floatValue(); }
    public int i() { return (int) Math.round(value); }
    public JsonElement toJson() { return new JsonPrimitive(value); }
    public void fromJson(JsonElement e) { set(e.getAsDouble()); }
    public String display() { return String.format(step >= 1 ? "%.0f" : "%.2f", value); }
    public void onLeft() { set(value + step); }
    @Override public void onRight() { set(value - step); }
}
