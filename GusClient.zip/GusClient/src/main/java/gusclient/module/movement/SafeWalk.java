package gusclient.module.movement;

import gusclient.module.*;
import gusclient.setting.*;

/** Auto-sneak di tepi blok supaya tidak jatuh. */
public class SafeWalk extends Module {
    private boolean forced;
    public SafeWalk() { super("SafeWalk", Category.MOVEMENT); }

    @Override public void onTick() {
        var p = mc.player;
        if (p == null) return;
        var v = p.getDeltaMovement();
        var box = p.getBoundingBox().move(v.x * 2, -0.6, v.z * 2);
        boolean edge = p.onGround() && mc.level.noCollision(p, box);
        if (edge) { mc.options.keyShift.setDown(true); forced = true; }
        else if (forced) { mc.options.keyShift.setDown(false); forced = false; }
    }

    @Override protected void onDisable() { if (forced) mc.options.keyShift.setDown(false); forced = false; }
}
