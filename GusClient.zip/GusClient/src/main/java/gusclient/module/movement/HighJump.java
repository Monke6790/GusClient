package gusclient.module.movement;

import gusclient.module.*;
import gusclient.setting.*;
import gusclient.util.MoveUtil;

public class HighJump extends Module {
    private final NumberSetting height = add(new NumberSetting("Jump Height", 0.6, 0.42, 1.5, 0.02));
    public HighJump() { super("HighJump", Category.MOVEMENT); }

    @Override public void onTick() {
        var p = mc.player;
        if (p == null || mc.screen != null) return;
        if (mc.options.keyJump.isDown() && p.onGround() && p.getDeltaMovement().y > 0) MoveUtil.setY(p, height.get());
    }
}
