package gusclient.module.movement;

import gusclient.module.*;
import gusclient.setting.*;

public class Sprint extends Module {
    private final BoolSetting omni = add(new BoolSetting("Omni Sprint", false));
    private final BoolSetting onlyMoving = add(new BoolSetting("Only When Moving", true));

    public Sprint() { super("Sprint", Category.MOVEMENT); }

    @Override public void onTick() {
        var p = mc.player;
        if (p == null || p.isUsingItem() || p.horizontalCollision || p.getFoodData().getFoodLevel() <= 6) return;
        boolean moving = p.zza > 0 || (omni.get() && (p.zza != 0 || p.xxa != 0));
        if (moving || !onlyMoving.get()) p.setSprinting(true);
    }

    @Override protected void onDisable() { if (mc.player != null) mc.player.setSprinting(false); }
}
