package gusclient.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;

public class BoolSetting extends Setting<Boolean> {
    public BoolSetting(String n, boolean d) { super(n, d); }
    public JsonElement toJson() { return new JsonPrimitive(value); }
    public void fromJson(JsonElement e) { value = e.getAsBoolean(); }
    public String display() { return value ? "ON" : "OFF"; }
    public void onLeft() { value = !value; }
}
