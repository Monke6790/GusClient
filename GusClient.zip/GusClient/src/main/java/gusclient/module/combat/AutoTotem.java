package gusclient.module.combat;

import gusclient.module.*;
import gusclient.setting.*;
import net.minecraft.network.chat.Component;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.item.Items;

public class AutoTotem extends Module {
    private final NumberSetting delay = add(new NumberSetting("Delay (ms)", 150, 0, 1000, 10));
    private final NumberSetting minHealth = add(new NumberSetting("Min Health", 20, 1, 20, 1));
    private final BoolSetting onlyNeeded = add(new BoolSetting("Only When Needed", true));
    private final BoolSetting debug = add(new BoolSetting("Debug Mode", false));
    private long last;
    public AutoTotem() { super("AutoTotem", Category.COMBAT); }

    @Override public void onTick() {
        var p = mc.player;
        if (p == null || mc.gameMode == null || mc.screen != null) return;
        if (p.getOffhandItem().is(Items.TOTEM_OF_UNDYING)) return;
        if (onlyNeeded.get() && p.getHealth() + p.getAbsorptionAmount() > minHealth.get()) return;
        if (System.currentTimeMillis() - last < delay.i()) return;
        var menu = p.inventoryMenu;
        for (int i = 9; i <= 44; i++) { // slot inventory + hotbar
            if (menu.getSlot(i).getItem().is(Items.TOTEM_OF_UNDYING)) {
                mc.gameMode.handleInventoryMouseClick(menu.containerId, i, 40, ClickType.SWAP, p);
                last = System.currentTimeMillis();
                if (debug.get()) p.displayClientMessage(Component.literal("AutoTotem: swap slot " + i), true);
                return;
            }
        }
    }
}
