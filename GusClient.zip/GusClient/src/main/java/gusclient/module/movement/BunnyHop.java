package gusclient.module.movement;

import gusclient.module.*;
import gusclient.setting.*;
import gusclient.util.MoveUtil;

public class BunnyHop extends Module {
    private final NumberSetting delay = add(new NumberSetting("Jump Delay", 0, 0, 10, 1));
    private final BoolSetting onlyMoving = add(new BoolSetting("Only While Moving", true));
    private int cooldown;
    public BunnyHop() { super("BunnyHop", Category.MOVEMENT); }

    @Override public void onTick() {
        var p = mc.player;
        if (p == null || mc.screen != null) return;
        if (cooldown > 0) { cooldown--; return; }
        if (p.onGround() && (!onlyMoving.get() || MoveUtil.isMoving(p)) && !p.isInWater()) {
            MoveUtil.setY(p, 0.42);
            cooldown = delay.i();
        }
    }
}
