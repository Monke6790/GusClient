package gusclient.util;

import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

public final class MoveUtil {
    private MoveUtil() {}

    public static boolean isMoving(Player p) { return p.zza != 0 || p.xxa != 0; }

    /** Set kecepatan horizontal (blok/tick) searah input; y tidak diubah. */
    public static void setSpeed(Player p, double speed) {
        double f = p.zza, s = p.xxa;
        if (f == 0 && s == 0) return;
        double yaw = Math.toRadians(p.getYRot());
        double len = Math.sqrt(f * f + s * s);
        f /= len; s /= len;
        double x = (-Math.sin(yaw) * f + Math.cos(yaw) * s) * speed;
        double z = (Math.cos(yaw) * f + Math.sin(yaw) * s) * speed;
        Vec3 v = p.getDeltaMovement();
        p.setDeltaMovement(x, v.y, z);
    }

    public static double hSpeed(Player p) { Vec3 v = p.getDeltaMovement(); return Math.hypot(v.x, v.z); }

    public static void setY(Player p, double y) { Vec3 v = p.getDeltaMovement(); p.setDeltaMovement(v.x, y, v.z); }

    public static Minecraft mc() { return Minecraft.getInstance(); }
}
