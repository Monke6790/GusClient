# GusClient (Fase 1)
Fabric client untuk Minecraft Java 1.21.11 (Java 21, Mojang mappings).

Build: `./gradlew build` -> `build/libs/GusClient.jar` (taruh di folder mods bersama Fabric API).
Menu: Right Shift. Klik kiri module = toggle, klik kanan = buka setting
(klik kiri/kanan pada setting = ubah nilai). Config: `.minecraft/config/gusclient.json`.

Kalau build error, kirim log lengkapnya. Versi di gradle.properties perlu dicocokkan
dengan https://fabricmc.net/develop.
